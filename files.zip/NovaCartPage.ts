import { Page, Locator } from '@playwright/test';

/**
 * NovaCartPage — Page Object for the NovaCart mock store.
 *
 * Locator properties are public so the framework's registerPageLocators()
 * can walk them and register each under the name `${pageName}_${key}`
 * (e.g. NovaCartPage_shopNow). Those names become the element_name stored
 * in the DB and used by the self-healing fallback engine.
 *
 * IMPORTANT for the healing demo:
 * Each locator below is the *primary* (POM) locator captured on v1. When the
 * page drifts (v2), these primary locators break and the framework heals from
 * the smart-locator bundle captured during the v1 run.
 */
export class NovaCartPage {

  // Step 1 — hero CTA
  readonly shopNow: Locator;

  // Step 2 — sort dropdown (STABLE across v1/v2)
  readonly sortSelect: Locator;

  // Step 3 — open a product (first product card's "View Product" link)
  readonly viewProduct: Locator;

  // Step 4 — size selector (size "M")
  readonly sizeM: Locator;

  // Step 5 — add to bag (in product modal)
  readonly addToBag: Locator;

  // Step 6 — view bag from the toast
  readonly viewBag: Locator;

  // Step 7 — promo code input (STABLE across v1/v2)
  readonly promoInput: Locator;

  // Step 8 — apply promo
  readonly applyPromo: Locator;

  // Step 9 — checkout
  readonly checkoutBtn: Locator;

  // Step 10 — done (checkout confirm)
  readonly checkoutDone: Locator;

  constructor(private page: Page) {
    // Primary (POM) locators as captured on v1. These intentionally use the
    // v1 ids; on v2 most ids change/drop, forcing the heal path.
    this.shopNow      = page.locator('#shop-now');
    this.sortSelect   = page.locator('#sort-select');
    this.viewProduct  = page.locator('[data-open-product]').first();
    this.sizeM        = page.locator('.size-btn[data-size="M"]');
    this.addToBag     = page.locator('#add-to-bag');
    this.viewBag      = page.locator('#view-bag');
    this.promoInput   = page.locator('#promo-input');
    this.applyPromo   = page.locator('#apply-promo');
    this.checkoutBtn  = page.locator('#checkout-btn');
    this.checkoutDone = page.locator('#checkout-done');
  }
}
