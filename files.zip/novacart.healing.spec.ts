/**
 * novacart.healing.spec.ts
 *
 * 10-STEP SELF-HEALING JOURNEY against the NovaCart mock store.
 *
 * Demonstrates (for the manager): a realistic multi-step user journey where the
 * page has DRIFTED between capture and replay, and the framework heals + refreshes
 * the stale primaries automatically — not one or two buttons, a full flow.
 *
 * TWO PHASES
 *   Phase 1 (CAPTURE)  — run the journey against novacart-v1.html. Every element
 *                        is captured & stored (primary + smart locators + meta).
 *   Phase 2 (REPLAY)   — run the SAME journey against novacart-v2.html, where 8 of
 *                        10 elements have drifted. Their v1 primaries break, the
 *                        framework heals via the smart-locator tier, and
 *                        refreshStaleElement updates the DB primary.
 *
 * 8 of 10 steps drift and heal; 2 (sort select, promo input) are stable and must
 * NOT heal or refresh — proving the "leave it alone when unchanged" path in the
 * same run.
 *
 * RUNNER: plain Playwright Test (no jest). DB writes are intercepted by
 * monkeypatching the repo functions so this runs without a live Postgres.
 *
 * PATHS: adjust the imports + FIXTURE paths to your repo layout.
 */

import { test, expect, Page } from '@playwright/test';
import path from 'path';

import BrowserActionImpl from '../src/core/actions/BrowserActionImpl'; // adjust
import { NovaCartPage } from '../src/pages/NovaCartPage';               // adjust
import * as elementRepo from '../src/core/db/elementRepo';
import * as healingRepo from '../src/core/db/healingRepo';

const V1 = 'file://' + path.resolve(__dirname, '../fixtures/novacart-v1.html');
const V2 = 'file://' + path.resolve(__dirname, '../fixtures/novacart-v2.html');

// Which steps are expected to drift (heal) vs stay stable.
const DRIFTED = new Set([
  'shopNow', 'viewProduct', 'sizeM', 'addToBag',
  'viewBag', 'applyPromo', 'checkoutBtn', 'checkoutDone',
]);
const STABLE = new Set(['sortSelect', 'promoInput']);

// ---------------------------------------------------------------------------
// In-memory "DB": Phase 1 capture writes here; Phase 2 replay reads from here.
// We intercept saveElement / getElement / refreshElementLocators so no real
// Postgres is needed and so we can assert on what got stored & refreshed.
// ---------------------------------------------------------------------------
type Row = {
  element_name: string;
  primary_locator: string;
  smart_locators: any;
  meta: any;
};
const store = new Map<string, Row>();
const refreshLog: { name: string; oldPrimary: string; newPrimary: string }[] = [];

let origSave: any, origGet: any, origRefresh: any, origLog: any;

test.beforeAll(() => {
  origSave = (elementRepo as any).saveElement;
  origGet = (elementRepo as any).getElement;
  origRefresh = (elementRepo as any).refreshElementLocators;
  origLog = (healingRepo as any).saveHealingLog;

  (healingRepo as any).saveHealingLog = async () => {};

  (elementRepo as any).saveElement = async (data: any) => {
    const row: Row = {
      element_name: data.elementName,
      primary_locator: data.primaryLocator,
      smart_locators: data.smartLocators ?? {},
      meta: data.meta ?? {},
    };
    store.set(row.element_name, row);
    return row;
  };

  (elementRepo as any).getElement = async (name: string) => {
    return store.get(name) ?? null;
  };

  (elementRepo as any).refreshElementLocators = async (
    name: string, primary: string, smart: any, meta: any
  ) => {
    const prev = store.get(name);
    refreshLog.push({
      name,
      oldPrimary: prev?.primary_locator ?? '(none)',
      newPrimary: primary,
    });
    store.set(name, {
      element_name: name,
      primary_locator: primary,
      smart_locators: smart,
      meta,
    });
    return { element_name: name, primary_locator: primary };
  };
});

test.afterAll(() => {
  (elementRepo as any).saveElement = origSave;
  (elementRepo as any).getElement = origGet;
  (elementRepo as any).refreshElementLocators = origRefresh;
  (healingRepo as any).saveHealingLog = origLog;
});

// ---------------------------------------------------------------------------
// Journey runner. Drives the 10 steps in order through BrowserActionImpl.
// Returns nothing; side effects land in `store` / `refreshLog`.
//
// NOTE on framework internals: BrowserActionImpl tries the live POM locator
// first, and only on failure calls findWithFallback (which heals + refreshes).
// On v1 every POM locator works -> capture path. On v2 the drifted ones throw
// -> heal path. Identical journey code, different page = different behavior.
// ---------------------------------------------------------------------------
async function runJourney(page: Page, action: any, pom: NovaCartPage) {
  // 1. Shop Now (hero CTA)
  await action.click(pom.shopNow);

  // 2. Sort dropdown (stable)
  await action.selectDropdownByValue(pom.sortSelect, 'price-low');

  // 3. Open a product
  await action.click(pom.viewProduct);

  // 4. Pick size M
  await action.click(pom.sizeM);

  // 5. Add to Bag
  await action.click(pom.addToBag);

  // 6. View Bag & Checkout (from toast)
  await action.click(pom.viewBag);

  // 7. Promo code input (stable)
  await action.type(pom.promoInput, 'SAVE10');

  // 8. Apply promo
  await action.click(pom.applyPromo);

  // 9. Checkout
  await action.click(pom.checkoutBtn);

  // 10. Done (checkout confirm)
  await action.click(pom.checkoutDone);
}

// Re-register POM locators with the framework so element_names are assigned.
// registerPageLocators is protected; we expose it via a tiny subclass shim.
class TestableAction extends (BrowserActionImpl as any) {
  registerForTest(pom: any) {
    // @ts-ignore — registerPageLocators is protected in the base class
    this.registerPageLocators(pom);
  }
}

// =============================================================================
// PHASE 1 — CAPTURE against v1
// =============================================================================
test('phase 1 — capture all 10 elements against v1', async ({ page }) => {
  await page.goto(V1);
  // open a product up front isn't needed; the journey opens it at step 3,
  // but size buttons only exist after the modal opens. The journey order
  // handles that (step 3 opens product, step 4 selects size).

  const action = new TestableAction();
  const pom = new NovaCartPage(page);
  action.registerForTest(pom);

  await runJourney(page, action, pom);

  // every element should now be captured
  for (const name of [...DRIFTED, ...STABLE]) {
    const stored = store.get(`NovaCartPage_${name}`);
    expect(stored, `expected ${name} captured on v1`).toBeTruthy();
  }

  // capture phase must NOT have triggered any refresh (page didn't drift)
  expect(refreshLog.length).toBe(0);
});

// =============================================================================
// PHASE 2 — REPLAY against v2 (drifted). 8 heal, 2 stay stable.
// =============================================================================
test('phase 2 — replay against v2: 8 heal + refresh, 2 stay stable', async ({ page }) => {
  refreshLog.length = 0;   // reset, only care about phase-2 refreshes

  await page.goto(V2);

  const action = new TestableAction();
  const pom = new NovaCartPage(page);
  action.registerForTest(pom);

  await runJourney(page, action, pom);

  // ---- Build the manager-facing summary ------------------------------------
  const refreshedNames = new Set(refreshLog.map(r => r.name.replace('NovaCartPage_', '')));

  console.log('\n================ HEALING JOURNEY SUMMARY (v1 -> v2) ================');
  const order = ['shopNow','sortSelect','viewProduct','sizeM','addToBag','viewBag','promoInput','applyPromo','checkoutBtn','checkoutDone'];
  order.forEach((name, i) => {
    const drifted = DRIFTED.has(name);
    const refreshed = refreshedNames.has(name);
    const entry = refreshLog.find(r => r.name === `NovaCartPage_${name}`);
    console.log(
      `Step ${String(i + 1).padStart(2)} | ${name.padEnd(13)} | ` +
      `${drifted ? 'DRIFTED' : 'stable '} | ` +
      `refreshed: ${refreshed ? 'YES' : 'no '} | ` +
      (entry ? `old="${entry.oldPrimary}"  ->  new="${entry.newPrimary}"` : '(primary unchanged)')
    );
  });
  console.log('===================================================================\n');

  // ---- Assertions ----------------------------------------------------------
  // Every drifted element must have been refreshed exactly once.
  for (const name of DRIFTED) {
    expect(
      refreshedNames.has(name),
      `expected ${name} to heal + refresh on v2`
    ).toBe(true);
  }

  // Stable elements must NOT have been refreshed.
  for (const name of STABLE) {
    expect(
      refreshedNames.has(name),
      `expected ${name} to stay stable (no refresh)`
    ).toBe(false);
  }

  // Total refreshes == number of drifted elements (no spurious writes).
  expect(refreshLog.length).toBe(DRIFTED.size);

  // Each refresh's new primary must differ from the old (real change written).
  for (const r of refreshLog) {
    expect(r.newPrimary).not.toBe(r.oldPrimary);
  }
});
